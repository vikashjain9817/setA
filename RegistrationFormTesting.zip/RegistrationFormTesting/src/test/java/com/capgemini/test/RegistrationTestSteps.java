package com.capgemini.test;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.Alert;

import com.capgemini.base.TestBaseDriver;
import com.capgemini.pages.RegistrationForm;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class RegistrationTestSteps extends TestBaseDriver{
	
	static RegistrationForm registrationForm;
	
	public RegistrationTestSteps(){
		super();
		setUp();
	}
	
	public static void setUp(){
		initialization();
		registrationForm = new RegistrationForm();
	}
	
	@Given("^The registrationPage is opening$")
	public void employeePage() throws Throwable {
		
	}

	@When("^The registrationPage  is open$")
	public void employeePageOpen() throws Throwable {
		
	}

	@Then("^then the title must be (.*)$")
	public void validateEmployeePage(String name) throws Throwable {
		String title = registrationForm.getTitle();
		assertEquals(name, title);
		Thread.sleep(2000);
		driver.quit();
	}
	
	@Given("^The registrationPage is open$")
	public void the_registrationPage_is_open() throws Throwable {
	}

	@When("^leave the userid field empty and click submit$")
	public void leave_the_userid_field_empty_and_click_submit() throws Throwable {
		registrationForm.setUserId(""); Thread.sleep(1000);
		registrationForm.setSub();
		Thread.sleep(2000);
	}
	
	@When("^given wrong userid field and click submit$")
	public void given_wrong_userid_field_and_click_submit() throws Throwable {
		registrationForm.setUserId("vikashajinvikashajin9817"); Thread.sleep(1000);
		registrationForm.setSub();
		Thread.sleep(2000);
	}
	
	@Then("^then the alert box displayed$")
	public void then_the_alert_box_displayed() throws Throwable {
		Alert alert = driver.switchTo().alert();
		String text = alert.getText();
		System.out.println("Alert: " +text);
		driver.quit();
	}
	
	@When("^leave the password field empty and click submit$")
	public void leave_the_password_field_empty_and_click_submit() throws Throwable {
		registrationForm.setUserId("vikash"); Thread.sleep(1000); 
		registrationForm.setPwd(""); Thread.sleep(1000);
		registrationForm.setSub();
		Thread.sleep(2000);
	}
	
	@When("^enter number in name field and click submit$")
	public void enter_number_in_name_field_and_click_submit() throws Throwable {
		registrationForm.setUserId("vikash"); Thread.sleep(1000); 
		registrationForm.setPwd("vikash12"); Thread.sleep(1000); 
		registrationForm.setName("123"); Thread.sleep(1000);
		registrationForm.setSub();
		Thread.sleep(2000);
	}
	
	@When("^given wrong password field and click submit$")
	public void given_wrong_password_field_and_click_submit() throws Throwable {
		registrationForm.setUserId("vikash"); Thread.sleep(1000); 
		registrationForm.setPwd("vikashjain08912872364"); Thread.sleep(1000);
		registrationForm.setSub();
		Thread.sleep(2000);
	}

	@When("^leave empty in name field and click submit$")
	public void leave_empty_in_name_field_and_click_submit() throws Throwable {
		registrationForm.setUserId("vikash"); Thread.sleep(1000); 
		registrationForm.setPwd("vikash12"); Thread.sleep(1000); 
		registrationForm.setName(""); Thread.sleep(1000);
		registrationForm.setSub();
		Thread.sleep(2000);
	}
	
	@When("^leave empty in address field and click submit$")
	public void leave_empty_in_address_field_and_click_submit() throws Throwable {
		registrationForm.setUserId("vikash"); Thread.sleep(1000); 
		registrationForm.setPwd("vikash12"); Thread.sleep(1000); 
		registrationForm.setName("vikash"); Thread.sleep(1000);
		registrationForm.setAdd(""); Thread.sleep(1000);
		registrationForm.setSub();
		Thread.sleep(2000);
	}

	@When("^enter number in address field and click submit$")
	public void enter_number_in_address_field_and_click_submit() throws Throwable {
		registrationForm.setUserId("vikash"); Thread.sleep(1000); 
		registrationForm.setPwd("vikash12"); Thread.sleep(1000); 
		registrationForm.setName("vikash"); Thread.sleep(1000);
		registrationForm.setAdd("vi@8352$#"); Thread.sleep(1000);
		registrationForm.setSub();
		Thread.sleep(2000);
	}
	
	@When("^do not select the country field and click submit$")
	public void do_not_select_the_country_field_and_click_submit() throws Throwable {
		registrationForm.setUserId("vikash"); Thread.sleep(1000); 
		registrationForm.setPwd("vikash12"); Thread.sleep(1000); 
		registrationForm.setName("vikash"); Thread.sleep(1000);
		registrationForm.setAdd("pune"); Thread.sleep(1000);
		registrationForm.setCountry("(Please select a country)"); Thread.sleep(1000);
		registrationForm.setSub();
		Thread.sleep(2000);
	}

	@When("^enter wrong data in zip field and click submit$")
	public void enter_wrong_data_in_zip_field_and_click_submit() throws Throwable {
		registrationForm.setUserId("vikash"); Thread.sleep(1000); 
		registrationForm.setPwd("vikash12"); Thread.sleep(1000); 
		registrationForm.setName("vikash"); Thread.sleep(1000);
		registrationForm.setAdd("pune"); Thread.sleep(1000);
		registrationForm.setCountry("India"); Thread.sleep(1000);
		registrationForm.setCode("sd");  Thread.sleep(1000);
		registrationForm.setSub();
		Thread.sleep(2000);
	}

	@When("^enter wrong data in email field and click submit$")
	public void enter_wrong_data_in_email_field_and_click_submit() throws Throwable {
		registrationForm.setUserId("vikash"); Thread.sleep(1000); 
		registrationForm.setPwd("vikash12"); Thread.sleep(1000); 
		registrationForm.setName("vikash"); Thread.sleep(1000);
		registrationForm.setAdd("pune"); Thread.sleep(1000);
		registrationForm.setCountry("India"); Thread.sleep(1000);
		registrationForm.setCode("411062");  Thread.sleep(1000);
		registrationForm.setEmail("vikash"); Thread.sleep(1000);
		registrationForm.setSub();
		Thread.sleep(2000);
	}
	
	@When("^do not select gender field and click submit$")
	public void do_not_select_gender_field_and_click_submit() throws Throwable {
		registrationForm.setUserId("vikash"); Thread.sleep(1000); 
		registrationForm.setPwd("vikash12"); Thread.sleep(1000); 
		registrationForm.setName("vikash"); Thread.sleep(1000);
		registrationForm.setAdd("pune"); Thread.sleep(1000);
		registrationForm.setCountry("India"); Thread.sleep(1000);
		registrationForm.setCode("411062");  Thread.sleep(1000);
		registrationForm.setEmail("vikashjain9817@gmail.com"); Thread.sleep(1000);
		registrationForm.setSub();
		Thread.sleep(2000);
	   
	}

	@When("^select default language and click submit$")
	public void select_default_language_and_click_submit() throws Throwable {
		registrationForm.setUserId("vikash"); Thread.sleep(1000); 
		registrationForm.setPwd("vikash12"); Thread.sleep(1000); 
		registrationForm.setName("vikash"); Thread.sleep(1000);
		registrationForm.setAdd("pune"); Thread.sleep(1000);
		registrationForm.setCountry("India"); Thread.sleep(1000);
		registrationForm.setCode("411062");  Thread.sleep(1000);
		registrationForm.setEmail("vikashjain9817@gmail.com"); Thread.sleep(1000);
		registrationForm.setMale();
		registrationForm.setLanguage("");
		registrationForm.setSub();
		Thread.sleep(2000);
	}


}
